import java.util.*;
public class EX_20 {

	public static void main(String[] args) {
		final int SIZE=5;
		int x=0,y=0,temp=0;
		
		int[][] bingo = new int[SIZE][SIZE];
		Scanner scanner = new Scanner(System.in);
		
		for(int i=0;i<SIZE;i++) {
			for(int j=0;j<SIZE;j++) {
				bingo[i][j] = i*SIZE+j+1;
			}
		}
		for(int i=0;i<SIZE;i++) {
			for(int j=0;j<SIZE;j++) {
				x=(int)(Math.random()*SIZE);
				y=(int)(Math.random()*SIZE);
				
				int tmp = bingo[i][j];
				bingo[i][j]=bingo[x][y];
				bingo[x][y]=tmp;
			}
		}
		do {
			for(int i=0;i<SIZE;i++) {
				for(int j=0;j<SIZE;j++) {
					System.out.printf("%3d",bingo[i][j]);
				}System.out.println();
			}
			System.out.println();
			
			System.out.printf("1~%d������ ������ �Է��ϼ���.(����:0)>",SIZE*SIZE);
			String input = scanner.nextLine();
			temp = Integer.parseInt(input);//�Է¹��� ���ڿ�(input)�� ���ڷ� ��ȯ�Ͽ� ����
			
			outer:
				for(int i=0;i<SIZE;i++) {
					for(int j=0;j<SIZE;j++) {
						if(bingo[i][j]==temp) {
							bingo[i][j]=0;
							break outer;
						}
					}
				}
		}while(temp!=0);
	}	

}
